Pour activer le son, charge un fichier SoundFont SF2 avec le bouton « BANQUE BATTERIE SF2 ».
La banque envisagée est MuldjordKit de FreePats (CC BY 4.0), environ 53 Mo.
Source officielle : https://freepats.zenvoid.org/Percussion/acoustic-drum-kit.html
Ce prototype ne contient pas encore le fichier SF2 lui-même.
