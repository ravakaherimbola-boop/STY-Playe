package com.example.styplayer

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/** Reads the Standard MIDI portion of a Yamaha PSR .STY and extracts one marked section. */
object YamahaStyleParser {
    enum class Section(val label: String, val aliases: List<String>) {
        INTRO1("INTRO 1", listOf("intro 1", "intro a", "intro")),
        A("VAR A", listOf("main a", "variation a", "var a", "main 1")),
        B("VAR B", listOf("main b", "variation b", "var b", "main 2")),
        C("VAR C", listOf("main c", "variation c", "var c", "main 3")),
        D("VAR D", listOf("main d", "variation d", "var d", "main 4")),
        ENDING1("ENDING 1", listOf("ending 1", "ending a", "ending"))
    }

    private data class MidiEvent(val tick: Long, val bytes: ByteArray, val marker: String? = null, val order: Int)
    private data class Parsed(val division: Int, val events: List<MidiEvent>)

    fun extractSection(sty: ByteArray, section: Section, output: File): File {
        val parsed = parseStyle(sty)
        val markers = parsed.events.mapNotNull { e -> e.marker?.let { e to it } }
        val startMarker = markers.firstOrNull { (_, text) -> matches(text, section) }
            ?: throw IllegalArgumentException("Section ${section.label} not found in this Yamaha STY.")
        val start = startMarker.first.tick
        val next = markers.firstOrNull { it.first.tick > start }
        val end = next?.first?.tick ?: parsed.events.maxOfOrNull { it.tick } ?: start
        if (end <= start) throw IllegalArgumentException("Section ${section.label} is empty.")

        val chosen = parsed.events.filter { e ->
            e.marker == null && (e.tick == 0L || (e.tick >= start && e.tick < end))
        }.map { e ->
            val newTick = if (e.tick == 0L) 0L else e.tick - start
            e.copy(tick = newTick)
        }.sortedWith(compareBy<MidiEvent> { it.tick }.thenBy { it.order })

        val track = ByteArrayOutputStream()
        var previous = 0L
        for (event in chosen) {
            val delta = (event.tick - previous).coerceAtLeast(0)
            writeVarLen(track, delta)
            track.write(event.bytes)
            previous = event.tick
        }
        writeVarLen(track, 0)
        track.write(byteArrayOf(0xFF.toByte(), 0x2F, 0x00))

        val trackBytes = track.toByteArray()
        val out = ByteArrayOutputStream()
        out.write("MThd".toByteArray(Charsets.US_ASCII))
        writeInt(out, 6)
        writeShort(out, 0) // format 0
        writeShort(out, 1)
        writeShort(out, parsed.division)
        out.write("MTrk".toByteArray(Charsets.US_ASCII))
        writeInt(out, trackBytes.size)
        out.write(trackBytes)
        FileOutputStream(output).use { it.write(out.toByteArray()) }
        return output
    }

    private fun matches(raw: String, section: Section): Boolean {
        val normalized = raw.lowercase(Locale.ROOT).replace('_', ' ').replace('-', ' ').trim()
        return section.aliases.any { alias -> normalized.contains(alias) }
    }

    private fun parseStyle(bytes: ByteArray): Parsed {
        val header = findChunk(bytes, "MThd", 0)
        if (header < 0 || header + 14 > bytes.size) throw IllegalArgumentException("Invalid Yamaha STY: MThd not found.")
        val headerLen = readInt(bytes, header + 4)
        if (headerLen < 6 || header + 8 + headerLen > bytes.size) throw IllegalArgumentException("Invalid MIDI header.")
        val division = readU16(bytes, header + 12)
        val trackPos = findChunk(bytes, "MTrk", header + 8 + headerLen)
        if (trackPos < 0 || trackPos + 8 > bytes.size) throw IllegalArgumentException("MIDI track not found in STY.")
        val declared = readInt(bytes, trackPos + 4).coerceAtLeast(0)
        val trackStart = trackPos + 8
        val casm = findChunk(bytes, "CASM", trackStart)
        val trackEnd = minOf(bytes.size, trackStart + declared, if (casm >= 0) casm else bytes.size)
        if (trackEnd <= trackStart) throw IllegalArgumentException("Empty MIDI track.")

        val events = ArrayList<MidiEvent>()
        var p = trackStart
        var tick = 0L
        var runningStatus = -1
        var order = 0
        while (p < trackEnd) {
            val deltaRead = readVarLen(bytes, p, trackEnd)
            tick += deltaRead.first
            p = deltaRead.second
            if (p >= trackEnd) break
            var status = bytes[p].toInt() and 0xFF
            val explicitStatus = status >= 0x80
            if (explicitStatus) {
                p++
                if (status in 0x80..0xEF) runningStatus = status
            } else {
                if (runningStatus < 0) throw IllegalArgumentException("Invalid MIDI running status.")
                status = runningStatus
            }
            val eventOut = ByteArrayOutputStream()
            eventOut.write(status)
            var marker: String? = null
            when {
                status == 0xFF -> {
                    if (p >= trackEnd) break
                    val type = bytes[p++].toInt() and 0xFF
                    val lenRead = readVarLen(bytes, p, trackEnd)
                    val len = lenRead.first.toInt()
                    p = lenRead.second
                    if (p + len > trackEnd) break
                    val data = bytes.copyOfRange(p, p + len)
                    p += len
                    eventOut.write(type); writeVarLen(eventOut, len.toLong()); eventOut.write(data)
                    if (type == 0x06 || type == 0x01 || type == 0x05) {
                        val text = data.toString(Charsets.ISO_8859_1).trim('\u0000', ' ', '\n', '\r')
                        if (text.isNotBlank()) marker = text
                    }
                    if (type == 0x2F) {
                        events.add(MidiEvent(tick, eventOut.toByteArray(), null, order++))
                        break
                    }
                }
                status == 0xF0 || status == 0xF7 -> {
                    val lenRead = readVarLen(bytes, p, trackEnd)
                    val len = lenRead.first.toInt(); p = lenRead.second
                    if (p + len > trackEnd) break
                    writeVarLen(eventOut, len.toLong()); eventOut.write(bytes, p, len); p += len
                }
                status in 0x80..0xEF -> {
                    val kind = status and 0xF0
                    val count = if (kind == 0xC0 || kind == 0xD0) 1 else 2
                    if (p + count > trackEnd) break
                    eventOut.write(bytes, p, count); p += count
                }
                else -> throw IllegalArgumentException("Unsupported MIDI event 0x${status.toString(16)}")
            }
            events.add(MidiEvent(tick, eventOut.toByteArray(), marker, order++))
        }
        if (events.none { it.marker != null }) throw IllegalArgumentException("No Yamaha section markers found in this STY.")
        return Parsed(division, events)
    }

    private fun findChunk(b: ByteArray, tag: String, from: Int): Int {
        val needle = tag.toByteArray(Charsets.US_ASCII)
        outer@ for (i in from.coerceAtLeast(0)..b.size - needle.size) {
            for (j in needle.indices) if (b[i + j] != needle[j]) continue@outer
            return i
        }
        return -1
    }
    private fun readInt(b: ByteArray, p: Int): Int = ByteBuffer.wrap(b, p, 4).order(ByteOrder.BIG_ENDIAN).int
    private fun readU16(b: ByteArray, p: Int): Int = ((b[p].toInt() and 255) shl 8) or (b[p + 1].toInt() and 255)
    private fun readVarLen(b: ByteArray, start: Int, end: Int): Pair<Long, Int> {
        var p = start; var value = 0L; var count = 0
        while (p < end && count++ < 4) {
            val v = b[p++].toInt() and 255
            value = (value shl 7) or (v and 0x7F).toLong()
            if (v and 0x80 == 0) return value to p
        }
        throw IllegalArgumentException("Broken MIDI variable-length value.")
    }
    private fun writeVarLen(out: ByteArrayOutputStream, value: Long) {
        var v = value.coerceAtLeast(0)
        var buffer = (v and 0x7F).toInt(); v = v shr 7
        while (v > 0) { buffer = (buffer shl 8) or (((v and 0x7F).toInt()) or 0x80); v = v shr 7 }
        while (true) { out.write(buffer and 0xFF); if (buffer and 0x80 != 0) buffer = buffer shr 8 else break }
    }
    private fun writeInt(out: ByteArrayOutputStream, v: Int) { out.write((v ushr 24) and 255); out.write((v ushr 16) and 255); out.write((v ushr 8) and 255); out.write(v and 255) }
    private fun writeShort(out: ByteArrayOutputStream, v: Int) { out.write((v ushr 8) and 255); out.write(v and 255) }
}
