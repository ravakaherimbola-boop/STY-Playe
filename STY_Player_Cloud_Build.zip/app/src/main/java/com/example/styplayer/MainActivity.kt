package com.example.styplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import dev.kotlinds.fluidsynthkmp.AudioConfig
import dev.kotlinds.fluidsynthkmp.Interpolation
import dev.kotlinds.fluidsynthkmp.MidiFilePlayer
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var styleBytes: ByteArray? = null
    private var soundFontFile: File? = null
    private var player: MidiFilePlayer? = null
    private var selectedSection: YamahaStyleParser.Section? = null
    private var loopEnabled = true
    private lateinit var fileLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var tempoLabel: TextView
    private var tempoBpm = 120

    private val openStyle = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) result.data?.data?.let { uri -> loadStyle(uri) }
    }
    private val openSoundFont = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) result.data?.data?.let { uri -> loadSoundFont(uri) }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildScreen() }

    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 22, 18, 20); setBackgroundColor(0xFF101114.toInt()) }
        fun text(value: String, size: Float, color: Int, gravityValue: Int = Gravity.START) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = gravityValue
        }
        root.addView(text("STY PLAYER", 27f, 0xFFFFFFFF.toInt(), Gravity.CENTER), match())
        root.addView(text("YAMAHA PSR • AUDIO PLAYER", 11f, 0xFFB9C0CC.toInt(), Gravity.CENTER), match())

        val open = button("📂  OUVRIR STY") { pickFile("*/*") }
        root.addView(open, match(14))
        fileLabel = text("Aucun fichier sélectionné", 13f, 0xFFE4E7ED.toInt())
        fileLabel.setPadding(3, 12, 3, 10); root.addView(fileLabel, match())

        val grid = GridLayout(this).apply { columnCount = 2 }
        val sections = listOf(
            YamahaStyleParser.Section.INTRO1, YamahaStyleParser.Section.A,
            YamahaStyleParser.Section.B, YamahaStyleParser.Section.C,
            YamahaStyleParser.Section.D, YamahaStyleParser.Section.ENDING1
        )
        sections.forEach { section ->
            val b = button(section.label) { playSection(section) }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0; height = dp(54); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        root.addView(grid, match(8))

        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        transport.addView(button("▶  PLAY") { selectedSection?.let { playSection(it) } ?: setStatus("Choisis une section.") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(4,4,4,4) })
        transport.addView(button("■  STOP") { stopPlayback() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(4,4,4,4) })
        root.addView(transport, match())

        val sf = button("🥁  BANQUE BATTERIE SF2") { pickFile("application/octet-stream") }
        root.addView(sf, match(8))
        root.addView(text("La banque MuldjordKit SF2 doit être chargée une fois.", 11f, 0xFFB9C0CC.toInt()), match())

        tempoLabel = text("TEMPO : 120 BPM", 15f, 0xFFFFFFFF.toInt())
        tempoLabel.setPadding(4, 14, 4, 0); root.addView(tempoLabel, match())
        root.addView(SeekBar(this).apply {
            max = 220; progress = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tempoBpm = p + 30; tempoLabel.text = "TEMPO : $tempoBpm BPM"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, match())

        root.addView(text("ÉGALISEUR", 17f, 0xFFFFFFFF.toInt()).apply { setPadding(4, 16, 4, 4) }, match())
        listOf("BASS", "LOW", "MID", "HIGH", "TREBLE").forEach { band ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(band, 11f, 0xFFD5D9E0.toInt()).apply { width = dp(64) })
            row.addView(SeekBar(this).apply { max = 100; progress = 50; isEnabled = false }, LinearLayout.LayoutParams(0, dp(36), 1f))
            root.addView(row, match())
        }
        statusLabel = text("Prêt", 12f, 0xFFFFC857.toInt()).apply { setPadding(4, 12, 4, 0) }
        root.addView(statusLabel, match())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun loadStyle(uri: Uri) {
        try {
            styleBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            fileLabel.text = uri.lastPathSegment ?: "Fichier STY chargé"
            setStatus("STY chargé. Choisis INTRO ou VAR A-D.")
        } catch (e: Exception) { setStatus("Impossible de lire ce fichier : ${e.message}") }
    }

    private fun loadSoundFont(uri: Uri) {
        try {
            val target = File(filesDir, "MuldjordKit.sf2")
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(target).use { input.copyTo(it) } }
            soundFontFile = target
            setStatus("Banque SF2 chargée (${target.length() / (1024 * 1024)} Mo).")
        } catch (e: Exception) { setStatus("Erreur banque SF2 : ${e.message}") }
    }

    private fun playSection(section: YamahaStyleParser.Section) {
        val bytes = styleBytes ?: run { setStatus("Ouvre d'abord un fichier Yamaha STY."); return }
        val sf = soundFontFile ?: run { setStatus("Charge la banque MuldjordKit SF2 pour entendre le son."); return }
        try {
            stopPlayback()
            val midi = YamahaStyleParser.extractSection(bytes, section, File(cacheDir, "section.mid"))
            val midiPlayer = MidiFilePlayer(
                soundFontPath = sf.absolutePath,
                midiPath = midi.absolutePath,
                config = AudioConfig(sampleRate = 44100, interpolation = Interpolation.NORMAL)
            )
            player = midiPlayer
            selectedSection = section
            setStatus("Lecture : ${section.label} (une fois).")
            midiPlayer.play { runOnUiThread { if (player === midiPlayer) { player = null; try { midiPlayer.close() } catch (_: Exception) {}; setStatus("Section terminée.") } } }
        } catch (e: Exception) { setStatus("Lecture impossible : ${e.message}") }
    }

    private fun stopPlayback() {
        val old = player
        player = null
        try { old?.stop(); old?.close() } catch (_: Exception) {}
        setStatus("Arrêté.")
    }

    private fun pickFile(mime: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (mime == "*/*") openStyle.launch(intent) else openSoundFont.launch(intent)
    }

    private fun setStatus(value: String) { if (::statusLabel.isInitialized) statusLabel.text = value }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF252832.toInt()); setOnClickListener { action() }
    }
    private fun match(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { if (top > 0) topMargin = dp(top) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() { stopPlayback(); super.onDestroy() }
}
