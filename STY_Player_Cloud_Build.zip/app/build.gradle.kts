plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.styplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.styplayer"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-audio-engine"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    // FluidSynth engine + bundled Android native libraries (ARM/ARM64/x86_64)
    implementation("dev.kotlinds:fluidsynth-kmp:1.1.1")
}
